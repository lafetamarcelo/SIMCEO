/*
 * File: AcOsh0_types.h
 *
 * Code generated for Simulink model 'AcOsh0'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
 * C/C++ source code generated on : Wed Sep  4 11:21:12 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_AcOsh0_types_h_
#define RTW_HEADER_AcOsh0_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_AcOsh0_T RT_MODEL_AcOsh0_T;

#endif                                 /* RTW_HEADER_AcOsh0_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
