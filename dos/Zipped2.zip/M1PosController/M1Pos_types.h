/*
 * File: M1Pos_types.h
 *
 * Code generated for Simulink model 'M1Pos'.
 *
 * Model version                  : 1.14
 * Simulink Coder version         : 8.14 (R2018a) 06-Feb-2018
 * C/C++ source code generated on : Wed Sep  4 11:54:33 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_M1Pos_types_h_
#define RTW_HEADER_M1Pos_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_M1Pos_T RT_MODEL_M1Pos_T;

#endif                                 /* RTW_HEADER_M1Pos_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
